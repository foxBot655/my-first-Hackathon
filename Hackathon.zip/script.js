let locations=document.getElementById("locations")

console.log(locations)


// GET Requests
async function getAPIData(URL) {
  let response = await fetch(URL) // make a call to our API 
  let json = await response.json() // turn the response into JSON
  console.log(json)
  return json 
}


async function updateHTML(){
  let API_URL = "https://data.cityofnewyork.us/resource/8nqg-ia7v.json" 
  // made my array (look console)
  let apiData = await getAPIData(API_URL)
  // do stuff with the data here

  // updating the HTML with data
  // step 1: get a reference to the list HTML
  locations.innerHTML = apiData.map((info) =>
      `<li>${info.name_1}; ${info.street_1};${info.street_1};${info.city} ${info.zip} (${info.phone}) </li>`
    ).join("")
  // let pokemonList = document.getElementById("pokemon-list")
  // console.log(pokemonList.innerHTML)
  
  // step 2: pull out our data 

  // let pokemonArray = apiData.results
  // console.log(pokemonArray)

  // step 3: AND... add items to the list HTML
  // take the pokemon array and turn it into an array of HTML
  // pokemonList.innerHTML = pokemonArray.map((pokemon, index) => `
  // <li class="list-group-item list-group-item-primary "> 
  // <div class="card" style="width: 18rem;">
  //   <img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${index + 1}.png" class="card-img-top" alt="...">
  //   <div class="card-body">
  //     <h5 class="card-title text-center">${pokemon.name}</h5>
  //   </div>
  // </div>

  // </li>
  // ` ).join("")


  // pokemonArray.forEach((pokemon, index)=>{
  //   // does something for every element in the array

  // })


  }

updateHTML()